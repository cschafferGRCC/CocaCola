﻿Public Class Form1
    Dim Product As String
    Dim Size As String

    Private Sub Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Product = "Nothing"

        CokeOriginal.Visible = True
        CokeZeroSugar.Visible = True
        DietCoke.Visible = True
        DietCokeCaffeineFree.Visible = True
        AHA.Visible = True
        RootBeer.Visible = True
        RootBeerZeroSugar.Visible = True
        Fanta.Visible = True
        FantaZero.Visible = True
        PowerAde.Visible = True
        HiC.Visible = True
        FuzeIcedTea.Visible = True
        MelloYello.Visible = True
        Pibb.Visible = True
        GingerAle.Visible = True
        DrPepper.Visible = True
        DrPepperDiet.Visible = True
        Sprite.Visible = True
        SpriteZero.Visible = True
        VitaminWater.Visible = True

        CocaCola2.Visible = False
        CokeCherry.Visible = False
        CokeCherryVanilla.Visible = False
        CokeLemon.Visible = False
        CokeLime.Visible = False
        CokeOrange.Visible = False
        CokeOrangeVanilla.Visible = False
        CokeRaspberry.Visible = False
        CokeVanilla.Visible = False
        CokeCremeSoda.Visible = False

    End Sub
    Private Sub CokeOriginal_Click(sender As Object, e As EventArgs) Handles CokeOriginal.Click
        CokeOriginal.Visible = False
        CokeZeroSugar.Visible = False
        DietCoke.Visible = False
        DietCokeCaffeineFree.Visible = False
        AHA.Visible = False
        RootBeer.Visible = False
        RootBeerZeroSugar.Visible = False
        Fanta.Visible = False
        FantaZero.Visible = False
        PowerAde.Visible = False
        HiC.Visible = False
        FuzeIcedTea.Visible = False
        MelloYello.Visible = False
        Pibb.Visible = False
        GingerAle.Visible = False
        DrPepper.Visible = False
        DrPepperDiet.Visible = False
        Sprite.Visible = False
        SpriteZero.Visible = False
        VitaminWater.Visible = False

        CocaCola2.Visible = True
        CokeCherry.Visible = True
        CokeCherryVanilla.Visible = True
        CokeLemon.Visible = True
        CokeLime.Visible = True
        CokeOrange.Visible = True
        CokeOrangeVanilla.Visible = True
        CokeRaspberry.Visible = True
        CokeVanilla.Visible = True
        CokeCremeSoda.Visible = True
    End Sub

    Private Sub CokeZeroSugar_Click(sender As Object, e As EventArgs) Handles CokeZeroSugar.Click
        Product = "Coke Zero"
        Product = Product + " " + "Coke Zero"
    End Sub

    Private Sub DietCoke_Click(sender As Object, e As EventArgs) Handles DietCoke.Click
        Product = "Diet Coke"
    End Sub

    Private Sub DietCokeCaffeineFree_Click(sender As Object, e As EventArgs) Handles DietCokeCaffeineFree.Click
        Product = "Diet Coke Caffeiene Free"
    End Sub

    Private Sub AHA_Click(sender As Object, e As EventArgs) Handles AHA.Click
        Product = "AHA"
    End Sub

    Private Sub RootBeer_Click(sender As Object, e As EventArgs) Handles RootBeer.Click
        Product = "RootBeer"
    End Sub

    Private Sub RootBeerZeroSugar_Click(sender As Object, e As EventArgs) Handles RootBeerZeroSugar.Click
        Product = "RootBeer Zero"
    End Sub

    Private Sub Fanta_Click(sender As Object, e As EventArgs) Handles Fanta.Click
        Product = "Fanta"
    End Sub

    Private Sub FantaZero_Click(sender As Object, e As EventArgs) Handles FantaZero.Click
        Product = "Fanta Zero"
    End Sub

    Private Sub PowerAde_Click(sender As Object, e As EventArgs) Handles PowerAde.Click
        Product = "Powerade"
    End Sub

    Private Sub HiC_Click(sender As Object, e As EventArgs) Handles HiC.Click
        Product = "Hi-C"
    End Sub

    Private Sub FuzeIcedTea_Click(sender As Object, e As EventArgs) Handles FuzeIcedTea.Click
        Product = "Fuzed Ice Tea"
    End Sub

    Private Sub MelloYello_Click(sender As Object, e As EventArgs) Handles MelloYello.Click
        Product = "Mello Yello"
    End Sub

    Private Sub Pibb_Click(sender As Object, e As EventArgs) Handles Pibb.Click
        Product = "Pibb"
    End Sub

    Private Sub GingerAle_Click(sender As Object, e As EventArgs) Handles GingerAle.Click
        Product = "Gingerale"
    End Sub

    Private Sub DrPepper_Click(sender As Object, e As EventArgs) Handles DrPepper.Click
        Product = "DrPepper"
    End Sub

    Private Sub DrPepperDiet_Click(sender As Object, e As EventArgs) Handles DrPepperDiet.Click
        Product = "Diet DrPepper"
    End Sub

    Private Sub Sprite_Click(sender As Object, e As EventArgs) Handles Sprite.Click
        Product = "Sprite"
    End Sub

    Private Sub SpriteZero_Click(sender As Object, e As EventArgs) Handles SpriteZero.Click
        Product = "Sprite Zero"
    End Sub

    Private Sub VitaminWater_Click(sender As Object, e As EventArgs) Handles VitaminWater.Click
        Product = "Vitamin Water"
    End Sub

    Private Sub btnMixDis_Click(sender As Object, e As EventArgs) Handles btnMixDis.Click
        MessageBox.Show("Dispensing: " & Size & " " & Product, "", MessageBoxButtons.OKCancel)

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnMainMenu_Click(sender As Object, e As EventArgs) Handles btnMainMenu.Click
        CokeOriginal.Visible = True
        CokeZeroSugar.Visible = True
        DietCoke.Visible = True
        DietCokeCaffeineFree.Visible = True
        AHA.Visible = True
        RootBeer.Visible = True
        RootBeerZeroSugar.Visible = True
        Fanta.Visible = True
        FantaZero.Visible = True
        PowerAde.Visible = True
        HiC.Visible = True
        FuzeIcedTea.Visible = True
        MelloYello.Visible = True
        Pibb.Visible = True
        GingerAle.Visible = True
        DrPepper.Visible = True
        DrPepperDiet.Visible = True
        Sprite.Visible = True
        SpriteZero.Visible = True
        VitaminWater.Visible = True

        CocaCola2.Visible = False
        CokeCherry.Visible = False
        CokeCherryVanilla.Visible = False
        CokeLemon.Visible = False
        CokeLime.Visible = False
        CokeOrange.Visible = False
        CokeOrangeVanilla.Visible = False
        CokeRaspberry.Visible = False
        CokeVanilla.Visible = False
        CokeCremeSoda.Visible = False
    End Sub

    Private Sub CocaCola2_Click(sender As Object, e As EventArgs) Handles CocaCola2.Click
        Product = "Coca-Cola Original"
    End Sub

    Private Sub CokeCherry_Click(sender As Object, e As EventArgs) Handles CokeCherry.Click
        Product = "Cherry Coke"
    End Sub

    Private Sub CokeCherryVanilla_Click(sender As Object, e As EventArgs) Handles CokeCherryVanilla.Click
        Product = "Cherry Vanilla Coke"
    End Sub

    Private Sub CokeLemon_Click(sender As Object, e As EventArgs) Handles CokeLemon.Click
        Product = "Lemon Coke"
    End Sub

    Private Sub CokeLime_Click(sender As Object, e As EventArgs) Handles CokeLime.Click
        Product = "Lime Coke"
    End Sub

    Private Sub CokeOrange_Click(sender As Object, e As EventArgs) Handles CokeOrange.Click
        Product = "Orange Coke"
    End Sub

    Private Sub CokeOrangeVanilla_Click(sender As Object, e As EventArgs) Handles CokeOrangeVanilla.Click
        Product = "Orange Vanilla Coke"
    End Sub

    Private Sub CokeRaspberry_Click(sender As Object, e As EventArgs) Handles CokeRaspberry.Click
        Product = "Raspberry Coke"
    End Sub

    Private Sub CokeVanilla_Click(sender As Object, e As EventArgs) Handles CokeVanilla.Click
        Product = "Vanilla Coke"
    End Sub

    Private Sub CokeCremeSoda_Click(sender As Object, e As EventArgs) Handles CokeCremeSoda.Click
        Product = "Creme Soda Coke"
    End Sub

    Private Sub Small_Click(sender As Object, e As EventArgs) Handles Small.Click
        Size = "8oz"
    End Sub

    Private Sub Medium_Click(sender As Object, e As EventArgs) Handles Medium.Click
        Size = "10oz"
    End Sub

    Private Sub Large_Click(sender As Object, e As EventArgs) Handles Large.Click
        Size = "12oz"
    End Sub
End Class
