﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FreeStyleMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FreeStyleMain))
        Me.CokeOriginal = New System.Windows.Forms.PictureBox()
        Me.DietCoke = New System.Windows.Forms.PictureBox()
        Me.CokeZeroSugar = New System.Windows.Forms.PictureBox()
        Me.DietCokeCaffeineFree = New System.Windows.Forms.PictureBox()
        Me.RootBeer = New System.Windows.Forms.PictureBox()
        Me.RootBeerZeroSugar = New System.Windows.Forms.PictureBox()
        Me.Fanta = New System.Windows.Forms.PictureBox()
        Me.FantaZero = New System.Windows.Forms.PictureBox()
        Me.HiC = New System.Windows.Forms.PictureBox()
        Me.DrPepper = New System.Windows.Forms.PictureBox()
        Me.FuzeIcedTea = New System.Windows.Forms.PictureBox()
        Me.MelloYello = New System.Windows.Forms.PictureBox()
        Me.Pibb = New System.Windows.Forms.PictureBox()
        Me.DrPepperDiet = New System.Windows.Forms.PictureBox()
        Me.Sprite = New System.Windows.Forms.PictureBox()
        Me.SpriteZero = New System.Windows.Forms.PictureBox()
        Me.AHA = New System.Windows.Forms.PictureBox()
        Me.PowerAde = New System.Windows.Forms.PictureBox()
        Me.GingerAle = New System.Windows.Forms.PictureBox()
        Me.VitaminWater = New System.Windows.Forms.PictureBox()
        Me.btnMixDis = New System.Windows.Forms.Button()
        Me.btnReports = New System.Windows.Forms.Button()
        Me.btnStat = New System.Windows.Forms.Button()
        Me.btnReOrder = New System.Windows.Forms.Button()
        Me.btnSyrupLvl = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnMainMenu = New System.Windows.Forms.Button()
        Me.CocaCola2 = New System.Windows.Forms.PictureBox()
        Me.CokeCherry = New System.Windows.Forms.PictureBox()
        Me.CokeCherryVanilla = New System.Windows.Forms.PictureBox()
        Me.CokeLemon = New System.Windows.Forms.PictureBox()
        Me.CokeLime = New System.Windows.Forms.PictureBox()
        Me.CokeOrange = New System.Windows.Forms.PictureBox()
        Me.CokeOrangeVanilla = New System.Windows.Forms.PictureBox()
        Me.CokeRaspberry = New System.Windows.Forms.PictureBox()
        Me.CokeVanilla = New System.Windows.Forms.PictureBox()
        Me.CokeCremeSoda = New System.Windows.Forms.PictureBox()
        Me.Small = New System.Windows.Forms.Label()
        Me.Large = New System.Windows.Forms.Label()
        Me.Medium = New System.Windows.Forms.Label()
        Me.ExtraLarge = New System.Windows.Forms.Label()
        CType(Me.CokeOriginal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DietCoke, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeZeroSugar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DietCokeCaffeineFree, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RootBeer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RootBeerZeroSugar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Fanta, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FantaZero, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HiC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DrPepper, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FuzeIcedTea, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MelloYello, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pibb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DrPepperDiet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Sprite, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SpriteZero, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AHA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PowerAde, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GingerAle, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VitaminWater, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CocaCola2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeCherry, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeCherryVanilla, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeLemon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeLime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeOrange, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeOrangeVanilla, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeRaspberry, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeVanilla, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CokeCremeSoda, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CokeOriginal
        '
        Me.CokeOriginal.Image = CType(resources.GetObject("CokeOriginal.Image"), System.Drawing.Image)
        Me.CokeOriginal.Location = New System.Drawing.Point(12, 12)
        Me.CokeOriginal.Name = "CokeOriginal"
        Me.CokeOriginal.Size = New System.Drawing.Size(105, 95)
        Me.CokeOriginal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeOriginal.TabIndex = 0
        Me.CokeOriginal.TabStop = False
        '
        'DietCoke
        '
        Me.DietCoke.Image = CType(resources.GetObject("DietCoke.Image"), System.Drawing.Image)
        Me.DietCoke.Location = New System.Drawing.Point(234, 12)
        Me.DietCoke.Name = "DietCoke"
        Me.DietCoke.Size = New System.Drawing.Size(105, 95)
        Me.DietCoke.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.DietCoke.TabIndex = 1
        Me.DietCoke.TabStop = False
        '
        'CokeZeroSugar
        '
        Me.CokeZeroSugar.Image = CType(resources.GetObject("CokeZeroSugar.Image"), System.Drawing.Image)
        Me.CokeZeroSugar.Location = New System.Drawing.Point(123, 12)
        Me.CokeZeroSugar.Name = "CokeZeroSugar"
        Me.CokeZeroSugar.Size = New System.Drawing.Size(105, 95)
        Me.CokeZeroSugar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeZeroSugar.TabIndex = 2
        Me.CokeZeroSugar.TabStop = False
        '
        'DietCokeCaffeineFree
        '
        Me.DietCokeCaffeineFree.Image = CType(resources.GetObject("DietCokeCaffeineFree.Image"), System.Drawing.Image)
        Me.DietCokeCaffeineFree.Location = New System.Drawing.Point(345, 12)
        Me.DietCokeCaffeineFree.Name = "DietCokeCaffeineFree"
        Me.DietCokeCaffeineFree.Size = New System.Drawing.Size(105, 95)
        Me.DietCokeCaffeineFree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.DietCokeCaffeineFree.TabIndex = 3
        Me.DietCokeCaffeineFree.TabStop = False
        '
        'RootBeer
        '
        Me.RootBeer.Image = CType(resources.GetObject("RootBeer.Image"), System.Drawing.Image)
        Me.RootBeer.Location = New System.Drawing.Point(12, 113)
        Me.RootBeer.Name = "RootBeer"
        Me.RootBeer.Size = New System.Drawing.Size(105, 95)
        Me.RootBeer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.RootBeer.TabIndex = 4
        Me.RootBeer.TabStop = False
        '
        'RootBeerZeroSugar
        '
        Me.RootBeerZeroSugar.Image = CType(resources.GetObject("RootBeerZeroSugar.Image"), System.Drawing.Image)
        Me.RootBeerZeroSugar.Location = New System.Drawing.Point(123, 113)
        Me.RootBeerZeroSugar.Name = "RootBeerZeroSugar"
        Me.RootBeerZeroSugar.Size = New System.Drawing.Size(105, 95)
        Me.RootBeerZeroSugar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.RootBeerZeroSugar.TabIndex = 5
        Me.RootBeerZeroSugar.TabStop = False
        '
        'Fanta
        '
        Me.Fanta.Image = CType(resources.GetObject("Fanta.Image"), System.Drawing.Image)
        Me.Fanta.Location = New System.Drawing.Point(234, 113)
        Me.Fanta.Name = "Fanta"
        Me.Fanta.Size = New System.Drawing.Size(105, 95)
        Me.Fanta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Fanta.TabIndex = 6
        Me.Fanta.TabStop = False
        '
        'FantaZero
        '
        Me.FantaZero.Image = CType(resources.GetObject("FantaZero.Image"), System.Drawing.Image)
        Me.FantaZero.Location = New System.Drawing.Point(345, 113)
        Me.FantaZero.Name = "FantaZero"
        Me.FantaZero.Size = New System.Drawing.Size(105, 95)
        Me.FantaZero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.FantaZero.TabIndex = 7
        Me.FantaZero.TabStop = False
        '
        'HiC
        '
        Me.HiC.Image = CType(resources.GetObject("HiC.Image"), System.Drawing.Image)
        Me.HiC.Location = New System.Drawing.Point(12, 214)
        Me.HiC.Name = "HiC"
        Me.HiC.Size = New System.Drawing.Size(105, 95)
        Me.HiC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.HiC.TabIndex = 8
        Me.HiC.TabStop = False
        '
        'DrPepper
        '
        Me.DrPepper.Image = CType(resources.GetObject("DrPepper.Image"), System.Drawing.Image)
        Me.DrPepper.Location = New System.Drawing.Point(12, 315)
        Me.DrPepper.Name = "DrPepper"
        Me.DrPepper.Size = New System.Drawing.Size(105, 95)
        Me.DrPepper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.DrPepper.TabIndex = 9
        Me.DrPepper.TabStop = False
        '
        'FuzeIcedTea
        '
        Me.FuzeIcedTea.Image = CType(resources.GetObject("FuzeIcedTea.Image"), System.Drawing.Image)
        Me.FuzeIcedTea.Location = New System.Drawing.Point(123, 214)
        Me.FuzeIcedTea.Name = "FuzeIcedTea"
        Me.FuzeIcedTea.Size = New System.Drawing.Size(105, 95)
        Me.FuzeIcedTea.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.FuzeIcedTea.TabIndex = 10
        Me.FuzeIcedTea.TabStop = False
        '
        'MelloYello
        '
        Me.MelloYello.Image = CType(resources.GetObject("MelloYello.Image"), System.Drawing.Image)
        Me.MelloYello.Location = New System.Drawing.Point(234, 214)
        Me.MelloYello.Name = "MelloYello"
        Me.MelloYello.Size = New System.Drawing.Size(105, 95)
        Me.MelloYello.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.MelloYello.TabIndex = 11
        Me.MelloYello.TabStop = False
        '
        'Pibb
        '
        Me.Pibb.Image = CType(resources.GetObject("Pibb.Image"), System.Drawing.Image)
        Me.Pibb.Location = New System.Drawing.Point(345, 214)
        Me.Pibb.Name = "Pibb"
        Me.Pibb.Size = New System.Drawing.Size(105, 95)
        Me.Pibb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pibb.TabIndex = 12
        Me.Pibb.TabStop = False
        '
        'DrPepperDiet
        '
        Me.DrPepperDiet.Image = CType(resources.GetObject("DrPepperDiet.Image"), System.Drawing.Image)
        Me.DrPepperDiet.Location = New System.Drawing.Point(123, 315)
        Me.DrPepperDiet.Name = "DrPepperDiet"
        Me.DrPepperDiet.Size = New System.Drawing.Size(105, 95)
        Me.DrPepperDiet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.DrPepperDiet.TabIndex = 13
        Me.DrPepperDiet.TabStop = False
        '
        'Sprite
        '
        Me.Sprite.Image = CType(resources.GetObject("Sprite.Image"), System.Drawing.Image)
        Me.Sprite.Location = New System.Drawing.Point(234, 315)
        Me.Sprite.Name = "Sprite"
        Me.Sprite.Size = New System.Drawing.Size(105, 95)
        Me.Sprite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Sprite.TabIndex = 14
        Me.Sprite.TabStop = False
        '
        'SpriteZero
        '
        Me.SpriteZero.Image = CType(resources.GetObject("SpriteZero.Image"), System.Drawing.Image)
        Me.SpriteZero.Location = New System.Drawing.Point(345, 315)
        Me.SpriteZero.Name = "SpriteZero"
        Me.SpriteZero.Size = New System.Drawing.Size(105, 95)
        Me.SpriteZero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.SpriteZero.TabIndex = 15
        Me.SpriteZero.TabStop = False
        '
        'AHA
        '
        Me.AHA.Image = CType(resources.GetObject("AHA.Image"), System.Drawing.Image)
        Me.AHA.Location = New System.Drawing.Point(456, 12)
        Me.AHA.Name = "AHA"
        Me.AHA.Size = New System.Drawing.Size(105, 95)
        Me.AHA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.AHA.TabIndex = 16
        Me.AHA.TabStop = False
        '
        'PowerAde
        '
        Me.PowerAde.Image = CType(resources.GetObject("PowerAde.Image"), System.Drawing.Image)
        Me.PowerAde.Location = New System.Drawing.Point(456, 113)
        Me.PowerAde.Name = "PowerAde"
        Me.PowerAde.Size = New System.Drawing.Size(105, 95)
        Me.PowerAde.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PowerAde.TabIndex = 17
        Me.PowerAde.TabStop = False
        '
        'GingerAle
        '
        Me.GingerAle.Image = CType(resources.GetObject("GingerAle.Image"), System.Drawing.Image)
        Me.GingerAle.Location = New System.Drawing.Point(456, 214)
        Me.GingerAle.Name = "GingerAle"
        Me.GingerAle.Size = New System.Drawing.Size(105, 95)
        Me.GingerAle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.GingerAle.TabIndex = 18
        Me.GingerAle.TabStop = False
        '
        'VitaminWater
        '
        Me.VitaminWater.Image = CType(resources.GetObject("VitaminWater.Image"), System.Drawing.Image)
        Me.VitaminWater.Location = New System.Drawing.Point(456, 315)
        Me.VitaminWater.Name = "VitaminWater"
        Me.VitaminWater.Size = New System.Drawing.Size(105, 95)
        Me.VitaminWater.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.VitaminWater.TabIndex = 19
        Me.VitaminWater.TabStop = False
        '
        'btnMixDis
        '
        Me.btnMixDis.Location = New System.Drawing.Point(602, 104)
        Me.btnMixDis.Name = "btnMixDis"
        Me.btnMixDis.Size = New System.Drawing.Size(123, 40)
        Me.btnMixDis.TabIndex = 1
        Me.btnMixDis.Text = "Mix/&Dispense"
        Me.btnMixDis.UseVisualStyleBackColor = True
        '
        'btnReports
        '
        Me.btnReports.Location = New System.Drawing.Point(602, 150)
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Size = New System.Drawing.Size(123, 40)
        Me.btnReports.TabIndex = 2
        Me.btnReports.Text = "&Reports"
        Me.btnReports.UseVisualStyleBackColor = True
        '
        'btnStat
        '
        Me.btnStat.Location = New System.Drawing.Point(602, 196)
        Me.btnStat.Name = "btnStat"
        Me.btnStat.Size = New System.Drawing.Size(123, 40)
        Me.btnStat.TabIndex = 3
        Me.btnStat.Text = "&Statistic"
        Me.btnStat.UseVisualStyleBackColor = True
        '
        'btnReOrder
        '
        Me.btnReOrder.Location = New System.Drawing.Point(602, 242)
        Me.btnReOrder.Name = "btnReOrder"
        Me.btnReOrder.Size = New System.Drawing.Size(123, 40)
        Me.btnReOrder.TabIndex = 4
        Me.btnReOrder.Text = "Re-&Order Syrup"
        Me.btnReOrder.UseVisualStyleBackColor = True
        '
        'btnSyrupLvl
        '
        Me.btnSyrupLvl.Location = New System.Drawing.Point(602, 288)
        Me.btnSyrupLvl.Name = "btnSyrupLvl"
        Me.btnSyrupLvl.Size = New System.Drawing.Size(123, 40)
        Me.btnSyrupLvl.TabIndex = 5
        Me.btnSyrupLvl.Text = "&Syrup Level"
        Me.btnSyrupLvl.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(567, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(203, 95)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 25
        Me.PictureBox1.TabStop = False
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(602, 380)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(123, 40)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "&Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnMainMenu
        '
        Me.btnMainMenu.Location = New System.Drawing.Point(602, 334)
        Me.btnMainMenu.Name = "btnMainMenu"
        Me.btnMainMenu.Size = New System.Drawing.Size(123, 40)
        Me.btnMainMenu.TabIndex = 6
        Me.btnMainMenu.Text = "&Main Menu"
        Me.btnMainMenu.UseVisualStyleBackColor = True
        '
        'CocaCola2
        '
        Me.CocaCola2.Image = CType(resources.GetObject("CocaCola2.Image"), System.Drawing.Image)
        Me.CocaCola2.Location = New System.Drawing.Point(12, 12)
        Me.CocaCola2.Name = "CocaCola2"
        Me.CocaCola2.Size = New System.Drawing.Size(105, 95)
        Me.CocaCola2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CocaCola2.TabIndex = 28
        Me.CocaCola2.TabStop = False
        '
        'CokeCherry
        '
        Me.CokeCherry.Image = CType(resources.GetObject("CokeCherry.Image"), System.Drawing.Image)
        Me.CokeCherry.Location = New System.Drawing.Point(123, 12)
        Me.CokeCherry.Name = "CokeCherry"
        Me.CokeCherry.Size = New System.Drawing.Size(105, 95)
        Me.CokeCherry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeCherry.TabIndex = 29
        Me.CokeCherry.TabStop = False
        '
        'CokeCherryVanilla
        '
        Me.CokeCherryVanilla.Image = CType(resources.GetObject("CokeCherryVanilla.Image"), System.Drawing.Image)
        Me.CokeCherryVanilla.Location = New System.Drawing.Point(234, 12)
        Me.CokeCherryVanilla.Name = "CokeCherryVanilla"
        Me.CokeCherryVanilla.Size = New System.Drawing.Size(105, 95)
        Me.CokeCherryVanilla.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeCherryVanilla.TabIndex = 30
        Me.CokeCherryVanilla.TabStop = False
        '
        'CokeLemon
        '
        Me.CokeLemon.Image = CType(resources.GetObject("CokeLemon.Image"), System.Drawing.Image)
        Me.CokeLemon.Location = New System.Drawing.Point(345, 12)
        Me.CokeLemon.Name = "CokeLemon"
        Me.CokeLemon.Size = New System.Drawing.Size(105, 95)
        Me.CokeLemon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeLemon.TabIndex = 31
        Me.CokeLemon.TabStop = False
        '
        'CokeLime
        '
        Me.CokeLime.Image = CType(resources.GetObject("CokeLime.Image"), System.Drawing.Image)
        Me.CokeLime.Location = New System.Drawing.Point(456, 12)
        Me.CokeLime.Name = "CokeLime"
        Me.CokeLime.Size = New System.Drawing.Size(105, 95)
        Me.CokeLime.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeLime.TabIndex = 32
        Me.CokeLime.TabStop = False
        '
        'CokeOrange
        '
        Me.CokeOrange.Image = CType(resources.GetObject("CokeOrange.Image"), System.Drawing.Image)
        Me.CokeOrange.Location = New System.Drawing.Point(12, 113)
        Me.CokeOrange.Name = "CokeOrange"
        Me.CokeOrange.Size = New System.Drawing.Size(105, 95)
        Me.CokeOrange.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeOrange.TabIndex = 33
        Me.CokeOrange.TabStop = False
        '
        'CokeOrangeVanilla
        '
        Me.CokeOrangeVanilla.Image = CType(resources.GetObject("CokeOrangeVanilla.Image"), System.Drawing.Image)
        Me.CokeOrangeVanilla.Location = New System.Drawing.Point(123, 113)
        Me.CokeOrangeVanilla.Name = "CokeOrangeVanilla"
        Me.CokeOrangeVanilla.Size = New System.Drawing.Size(105, 95)
        Me.CokeOrangeVanilla.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeOrangeVanilla.TabIndex = 34
        Me.CokeOrangeVanilla.TabStop = False
        '
        'CokeRaspberry
        '
        Me.CokeRaspberry.Image = CType(resources.GetObject("CokeRaspberry.Image"), System.Drawing.Image)
        Me.CokeRaspberry.Location = New System.Drawing.Point(234, 113)
        Me.CokeRaspberry.Name = "CokeRaspberry"
        Me.CokeRaspberry.Size = New System.Drawing.Size(105, 95)
        Me.CokeRaspberry.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeRaspberry.TabIndex = 35
        Me.CokeRaspberry.TabStop = False
        '
        'CokeVanilla
        '
        Me.CokeVanilla.Image = CType(resources.GetObject("CokeVanilla.Image"), System.Drawing.Image)
        Me.CokeVanilla.Location = New System.Drawing.Point(345, 113)
        Me.CokeVanilla.Name = "CokeVanilla"
        Me.CokeVanilla.Size = New System.Drawing.Size(105, 95)
        Me.CokeVanilla.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeVanilla.TabIndex = 36
        Me.CokeVanilla.TabStop = False
        '
        'CokeCremeSoda
        '
        Me.CokeCremeSoda.Image = CType(resources.GetObject("CokeCremeSoda.Image"), System.Drawing.Image)
        Me.CokeCremeSoda.Location = New System.Drawing.Point(456, 113)
        Me.CokeCremeSoda.Name = "CokeCremeSoda"
        Me.CokeCremeSoda.Size = New System.Drawing.Size(105, 95)
        Me.CokeCremeSoda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CokeCremeSoda.TabIndex = 37
        Me.CokeCremeSoda.TabStop = False
        '
        'Small
        '
        Me.Small.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Small.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Small.Location = New System.Drawing.Point(86, 426)
        Me.Small.Name = "Small"
        Me.Small.Size = New System.Drawing.Size(66, 25)
        Me.Small.TabIndex = 39
        Me.Small.Text = "8oz"
        '
        'Large
        '
        Me.Large.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Large.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Large.Location = New System.Drawing.Point(312, 426)
        Me.Large.Name = "Large"
        Me.Large.Size = New System.Drawing.Size(66, 25)
        Me.Large.TabIndex = 40
        Me.Large.Text = "24oz"
        '
        'Medium
        '
        Me.Medium.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Medium.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Medium.Location = New System.Drawing.Point(195, 426)
        Me.Medium.Name = "Medium"
        Me.Medium.Size = New System.Drawing.Size(66, 25)
        Me.Medium.TabIndex = 41
        Me.Medium.Text = "16oz"
        '
        'ExtraLarge
        '
        Me.ExtraLarge.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ExtraLarge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ExtraLarge.Location = New System.Drawing.Point(425, 426)
        Me.ExtraLarge.Name = "ExtraLarge"
        Me.ExtraLarge.Size = New System.Drawing.Size(66, 25)
        Me.ExtraLarge.TabIndex = 42
        Me.ExtraLarge.Text = "32oz"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(773, 491)
        Me.Controls.Add(Me.ExtraLarge)
        Me.Controls.Add(Me.Medium)
        Me.Controls.Add(Me.Large)
        Me.Controls.Add(Me.Small)
        Me.Controls.Add(Me.CokeCremeSoda)
        Me.Controls.Add(Me.CokeVanilla)
        Me.Controls.Add(Me.CokeRaspberry)
        Me.Controls.Add(Me.CokeOrangeVanilla)
        Me.Controls.Add(Me.CokeOrange)
        Me.Controls.Add(Me.CokeLime)
        Me.Controls.Add(Me.CokeLemon)
        Me.Controls.Add(Me.CokeCherryVanilla)
        Me.Controls.Add(Me.CokeCherry)
        Me.Controls.Add(Me.CocaCola2)
        Me.Controls.Add(Me.btnMainMenu)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnSyrupLvl)
        Me.Controls.Add(Me.btnReOrder)
        Me.Controls.Add(Me.btnStat)
        Me.Controls.Add(Me.btnReports)
        Me.Controls.Add(Me.btnMixDis)
        Me.Controls.Add(Me.VitaminWater)
        Me.Controls.Add(Me.GingerAle)
        Me.Controls.Add(Me.PowerAde)
        Me.Controls.Add(Me.AHA)
        Me.Controls.Add(Me.SpriteZero)
        Me.Controls.Add(Me.Sprite)
        Me.Controls.Add(Me.DrPepperDiet)
        Me.Controls.Add(Me.Pibb)
        Me.Controls.Add(Me.MelloYello)
        Me.Controls.Add(Me.FuzeIcedTea)
        Me.Controls.Add(Me.DrPepper)
        Me.Controls.Add(Me.HiC)
        Me.Controls.Add(Me.FantaZero)
        Me.Controls.Add(Me.Fanta)
        Me.Controls.Add(Me.RootBeerZeroSugar)
        Me.Controls.Add(Me.RootBeer)
        Me.Controls.Add(Me.DietCokeCaffeineFree)
        Me.Controls.Add(Me.CokeZeroSugar)
        Me.Controls.Add(Me.DietCoke)
        Me.Controls.Add(Me.CokeOriginal)
        Me.Name = "Form1"
        Me.Text = "Freestyle Coca-Cola Machine"
        CType(Me.CokeOriginal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DietCoke, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeZeroSugar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DietCokeCaffeineFree, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RootBeer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RootBeerZeroSugar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Fanta, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FantaZero, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HiC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DrPepper, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FuzeIcedTea, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MelloYello, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pibb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DrPepperDiet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Sprite, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SpriteZero, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AHA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PowerAde, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GingerAle, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VitaminWater, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CocaCola2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeCherry, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeCherryVanilla, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeLemon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeLime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeOrange, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeOrangeVanilla, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeRaspberry, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeVanilla, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CokeCremeSoda, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents CokeOriginal As PictureBox
    Friend WithEvents DietCoke As PictureBox
    Friend WithEvents CokeZeroSugar As PictureBox
    Friend WithEvents DietCokeCaffeineFree As PictureBox
    Friend WithEvents RootBeer As PictureBox
    Friend WithEvents RootBeerZeroSugar As PictureBox
    Friend WithEvents Fanta As PictureBox
    Friend WithEvents FantaZero As PictureBox
    Friend WithEvents HiC As PictureBox
    Friend WithEvents DrPepper As PictureBox
    Friend WithEvents FuzeIcedTea As PictureBox
    Friend WithEvents MelloYello As PictureBox
    Friend WithEvents Pibb As PictureBox
    Friend WithEvents DrPepperDiet As PictureBox
    Friend WithEvents Sprite As PictureBox
    Friend WithEvents SpriteZero As PictureBox
    Friend WithEvents AHA As PictureBox
    Friend WithEvents PowerAde As PictureBox
    Friend WithEvents GingerAle As PictureBox
    Friend WithEvents VitaminWater As PictureBox
    Friend WithEvents btnMixDis As Button
    Friend WithEvents btnReports As Button
    Friend WithEvents btnStat As Button
    Friend WithEvents btnReOrder As Button
    Friend WithEvents btnSyrupLvl As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnMainMenu As Button
    Friend WithEvents CocaCola2 As PictureBox
    Friend WithEvents CokeCherry As PictureBox
    Friend WithEvents CokeCherryVanilla As PictureBox
    Friend WithEvents CokeLemon As PictureBox
    Friend WithEvents CokeLime As PictureBox
    Friend WithEvents CokeOrange As PictureBox
    Friend WithEvents CokeOrangeVanilla As PictureBox
    Friend WithEvents CokeRaspberry As PictureBox
    Friend WithEvents CokeVanilla As PictureBox
    Friend WithEvents CokeCremeSoda As PictureBox
    Friend WithEvents Small As Label
    Friend WithEvents Large As Label
    Friend WithEvents Medium As Label
    Friend WithEvents ExtraLarge As Label
End Class
